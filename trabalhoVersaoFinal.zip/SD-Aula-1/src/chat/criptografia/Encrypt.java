package chat.criptografia;
import java.math.BigInteger;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import chat.enums.TipoCryptoEnum;

public class Encrypt {

     public static byte[] encrypt(String textopuro, String chaveencriptacao) throws Exception {
    	 System.out.println("Encriptando mensagem: " + textopuro);
    	 Cipher encripta = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
    	 SecretKeySpec key = new SecretKeySpec(chaveencriptacao.getBytes("UTF-8"), "AES");
    	 encripta.init(Cipher.ENCRYPT_MODE, key,new IvParameterSpec("AAAAAAAAAAAAAAAA".getBytes("UTF-8")));
    	 byte[] result =  encripta.doFinal(textopuro.getBytes("UTF-8"));
    	 System.out.println("Mensagem encriptada: " + new BigInteger(result) + "\n");
    	 return result;
     }

     public static String decrypt(byte[] textoencriptado, String chaveencriptacao) throws Exception{
    	 System.out.println("Decodificando mensagem: " + new BigInteger(textoencriptado));
    	 Cipher decripta = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
    	 SecretKeySpec key = new SecretKeySpec(chaveencriptacao.getBytes("UTF-8"), "AES");
    	 decripta.init(Cipher.DECRYPT_MODE, key,new IvParameterSpec("AAAAAAAAAAAAAAAA".getBytes("UTF-8")));
    	 String result =  new String(decripta.doFinal(textoencriptado),"UTF-8");
    	 System.out.println("Mensagem decodificada: " +  result);
    	 return result;
     }
     
     
     public static long calculatePower(long chavePublicaA, long chavePrivadaA, long chavePublicaB) {  
    	 long result = 0;          
         if (chavePrivadaA == 1){  
             return chavePublicaA;  
         }  
         else{  
             result = ((long)Math.pow(chavePublicaA, chavePrivadaA)) % chavePublicaB;  
             return result;  
         }  
     }  
     
     public static String criarChaveDeAcordoComCrypto(Long chaveSecretaCompartilhada, TipoCryptoEnum tipoCrypto ) {
    	 String chaveSecretaCompartilhadaString = String.valueOf(chaveSecretaCompartilhada);
    	 
    	 for(int i = 0 ; i < 8 ; i++) {
    		 chaveSecretaCompartilhadaString = chaveSecretaCompartilhadaString.concat(chaveSecretaCompartilhadaString);
    	 }
    	 switch (tipoCrypto) {
 		case C128: {
 			 return chaveSecretaCompartilhadaString.substring(0, TipoCryptoEnum.C128.getSize());
 		}
		case C192: {
			return chaveSecretaCompartilhadaString.substring(0, TipoCryptoEnum.C192.getSize());
		}
		case C256:{
			return chaveSecretaCompartilhadaString.substring(0, TipoCryptoEnum.C256.getSize());
		}
		default:
		}
    	 return "";
     }
}
