package chat.servidor;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import chat.cliente.Cliente;

public class EscutaServidor implements Runnable {

	private Socket socket;

	public EscutaServidor(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			while (true) {

				InputStreamReader in = new InputStreamReader(socket.getInputStream());
				BufferedReader bf = new BufferedReader(in);
				if (bf.ready()) {
					String txt = "";
					int i;
					while ((i = bf.read()) != 0) {
						if (i > 0) {
							char c = (char) i;
							txt = txt + String.valueOf(c);
						}
						if (!bf.ready()) {
							break;
						}
					}
					//Ajuste tecnico :D
					if (!String.valueOf(txt.charAt(0)).equals("S")) {
						System.out.println("[Servidor] Recebendo mensagem: " + txt);
						
						//Verifica se a mensagem � referente ao envio das chaves para o calculo da chave secreta compartilhada
						if(isCrypto(txt)) {
							//Envia a mensagem apenas para o outro cliente (a mensagem n�o volta para quem enviou)
							Integer idClienteMensagemOrigem = buscaCodigoCliente(txt);
							
							for (Cliente cliente : ServidorController.socketsConectados) {
								if(cliente.getSocket().getLocalPort() != idClienteMensagemOrigem) {
									enviaMensagem(cliente, txt);
								}
							}
						}else {
						//Sen�o segue o fluxo normal, envia a mensagem para todos os usu�rios conectados (a mensagem volta para quem enviou tamb�m)
							for (Cliente cliente : ServidorController.socketsConectados) {
								enviaMensagem(cliente, txt);
							}
							
						}

					}

				}else {
					Thread.sleep(200);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Integer buscaCodigoCliente(String txt) {
		return Integer.valueOf(txt.split("\\|")[0].trim());
	}
	
	private Boolean isCrypto(String mensagem) {
		return mensagem.contains("CRYPTO");
	}
	
	/**
	 *M�todo que envia a mensagem;
	 */
	private void enviaMensagem(Cliente cliente, String mensagem) {
		try {
			
			Socket s = ServidorController.socketsAceitos
						      .stream()
							  .filter(f -> f.getPort() == cliente.getSocket().getLocalPort())
							  .findFirst()
							  .get();
			
			PrintWriter pr;
			pr = new PrintWriter(s.getOutputStream());
			pr.print("S"+mensagem);
			pr.flush();
			System.out.println("[Servidor] Enviando mensagem para " + cliente.getNmCliente());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
