package chat.servidor;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import chat.cliente.Cliente;
import chat.cliente.EscutaCliente;
import chat.enums.TipoCryptoEnum;

public class ServidorController {
	
	public static ServerSocket serverSocket;
	public static List<Cliente> socketsConectados = new ArrayList<Cliente>();
	public static List<Socket> socketsAceitos = new ArrayList<Socket>();
	public static Integer PORTA_PADRAO = 8899;
	public static TipoCryptoEnum tipoCrypto;
	
	public static Long chavePublica1 = 33l;
	public static Long chavePrivada1 = 3l;
	
	public static Long chavePublica2 = 8l;
	public static Long chavePrivada2 = 2l;
	
	//Flag respons�vel por informar se as chaves secretas compartilhadas dos clientes j� foram criadas
	public static Boolean isCrypto = false;
	
	public ServidorController() {

	}
	/**
	 *M�todo que inicializa o servidor
	 */
    public static boolean startServer(TipoCryptoEnum tipoCryptoEnum){
		try {
			tipoCrypto = tipoCryptoEnum;
			serverSocket = new ServerSocket(PORTA_PADRAO);
			imprimeInformacoesServidor();
			new Thread(new Runnable() {
				@Override
				public void run() {
					try{
		            	while (true){
		            		Socket s = serverSocket.accept();
		            		socketsAceitos.add(s);
		            		Thread.sleep(1000);
		            		Cliente c = buscaCliente(s.getPort());
		            		System.out.println("Usuario: " + c.getNmCliente() + " --> conectado!\n");
		            		c.getEscutaCliente().exibirPainel();
		            		new Thread(new EscutaServidor(s)).start();
		                	Thread.sleep(200);
						}
		            } catch (Exception e){System.out.println(e.getMessage());}
				}
			}).start();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
    }
    
	private static void imprimeInformacoesServidor() {
		System.out.println("= = = = = = = = = = = = = = = = = = = =");
		System.out.println("Servidor ligado com sucesso!");
        System.out.println("Server IP address: " + serverSocket.getInetAddress().getHostAddress());
        System.out.println("Server Port: " + PORTA_PADRAO);
        System.out.println("Server Encryption: " + tipoCrypto);
        System.out.println("= = = = = = = = = = = = = = = = = = = =\n");
	}

	public static boolean isServidorAtivo() {
		return null != serverSocket;
	}

	public static void adicionarCliente(Cliente c) {
		try {
			Socket socket = new Socket("127.0.1.1", PORTA_PADRAO);
			c.setSocket(socket);
			c.setEscutaCliente(new EscutaCliente(c));
			socketsConectados.add(c);
		} catch (Exception e) {e.printStackTrace();}

	}
	
	public static Cliente buscaCliente(Integer localPort) {
		for (Cliente cliente : socketsConectados) {
			if (cliente.getSocket().getLocalPort() == localPort) {
				return cliente;
			}
		}
		return null;
	}
}
