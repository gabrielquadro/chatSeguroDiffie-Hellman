package chat.cliente;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;

import chat.PainelChatFrm;
import chat.criptografia.Encrypt;
import chat.servidor.ServidorController;

public class EscutaCliente {

	private Cliente cliente;
	private PainelChatFrm painel;
	
	public EscutaCliente(Cliente cliente) {
		this.cliente = cliente;
		painel = new PainelChatFrm(cliente);

	}

	private Runnable escuta = new Runnable() {
		@Override
		public void run() {
			try {
				while (true) {
					InputStreamReader in = new InputStreamReader(cliente.getSocket().getInputStream());
					BufferedReader bf = new BufferedReader(in);
					if (bf.ready()) {
						String txt = "";
						int i;
						while ((i = bf.read()) != 0) {
							if (i > 0) {
								char c = (char) i;
								txt = txt + String.valueOf(c);
							}
							if (!bf.ready()) {
								break;
							}
						}
						txt = txt.replaceFirst("S", "");
						System.out.println("[Cliente] Usuario " + cliente.getNmCliente() + ", recebendo a mensagem: " + txt + "\n");
						
						//Verifica se a mensagem � referente ao envio das chaves para o calculo da chave secreta compartilhada
						if(isCrypto(txt)) {
							Long valorPublicoA = Long.valueOf(txt.split("\\|")[2].replaceAll("CRYPTO", ""));
							//Calculando valor publico B
							Long valorPublicoB = Encrypt.calculatePower(ServidorController.chavePublica2, cliente.getChavePrivada(), ServidorController.chavePublica1);
							System.out.println("Chave privada de "+ cliente.getNmCliente() + ": " + cliente.getChavePrivada());
							System.out.println("Chave publica de "+ cliente.getNmCliente() + ": " + ServidorController.chavePublica2);
							System.out.println("Valor publico de " + cliente.getNmCliente() + ": " + valorPublicoB);
							//Setando chave secreta compartilhada
							cliente.setChaveSecretaCompartilhada(Encrypt.calculatePower(valorPublicoA, cliente.getChavePrivada(), ServidorController.chavePublica1));
							System.out.println("Chave secreta compartilhada de " + cliente.getNmCliente() + ": " + cliente.getChaveSecretaCompartilhada() + "\n");
							//Envia a mensagem novamente, agora com a flag CRYPTOBACK
							String mensagem = cliente.getSocket().getLocalPort() + "|" + cliente.getNmCliente() + "|" + "CRYPTOBACK" + String.valueOf(valorPublicoB);
							enviar(mensagem);
						//Verifica se a mensagem � referente ao envio das chaves para o calculo da chave secreta compartilhada (RETORNO)
						}else if(isCryptoBack(txt)) {
							Long valorPublicoB = Long.valueOf(txt.split("\\|")[2].replaceAll("CRYPTOBACK", ""));
							//Setando chave secreta compartilhada
							cliente.setChaveSecretaCompartilhada(Encrypt.calculatePower(valorPublicoB, cliente.getChavePrivada(), ServidorController.chavePublica1));
							System.out.println("Chave secreta compartilhada de " + cliente.getNmCliente() + ": " + cliente.getChaveSecretaCompartilhada());
							ServidorController.isCrypto = Boolean.TRUE;
						}else {
							updateScreenFromServer(txt);
						}
					};
					Thread.sleep(200);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		private boolean isCryptoBack(String txt) {
			return txt.contains("CRYPTOBACK");
		}

		private boolean isCrypto(String txt) {
			return txt.contains("CRYPTO") && !txt.contains("CRYPTOBACK");
		}
	};
	
	/**
	 *M�todo respons�vel por atualizar a tela do chat, deixando a mensagem formatada
	 */
	private void updateScreenFromServer(String txt) {
		String chave = Encrypt.criarChaveDeAcordoComCrypto(cliente.getChaveSecretaCompartilhada(), ServidorController.tipoCrypto);
		BigInteger v = new BigInteger(txt);
		try {
			txt = Encrypt.decrypt(v.toByteArray(), chave);
		} catch (Exception e) {
			e.printStackTrace();
		}

		txt = txt.replace("|", ": ");
		String taChat = painel.getTaChat().getText();
		taChat = taChat.concat("\n" + txt);
		painel.getTaChat().setText(taChat);
		painel.getFtEntrada().setText("");
	}
	
	/**
	 *M�todo respons�vel pelo envio de mensagens.
	 */
	public void enviarMensagem(String mensagem) {
		if (null == mensagem || mensagem.isEmpty()) {
			return;
		}
		
		//Verifica se as chaves secretas compartilhadas j� foram criadas
		if(!ServidorController.isCrypto) {
			enviaChaveSecretaCompartilhada();
			//Como as threads n�o s�o sincronizadas, � necess�rio inserir alguns Thread.sleep() para garantir que elas terminem sua execu��o antes de proceguir.
			//Na pr�tica, foi pregui�a de implementar sincroniza��o :/
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		//O c�digo trava aqui at� que a parte de calcular as chaves seja finalizada. Pois n�o podemos encriptar as mensagens sem antes termos as chaves.
		do{
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}while (ServidorController.isCrypto == Boolean.FALSE) ;
		//Ap�s as chaves serem calculadas, � aqui que a mensagem do usu�rio ser� enviada para o servidor.
		try {
			//O formato da mensagem �: nomeDoCliente|Mensagem
			mensagem = cliente.getNmCliente() + "|" + mensagem;
			//Gerando chave de encripta��o a partir da chave secreta compartilhada
			String chave = Encrypt.criarChaveDeAcordoComCrypto(cliente.getChaveSecretaCompartilhada(), ServidorController.tipoCrypto);
			//Encriptando mensagem
			BigInteger mensagemEncriptada = new BigInteger(Encrypt.encrypt(mensagem, chave));
			//Enviando
			enviar(String.valueOf(mensagemEncriptada));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 *M�todo que inicia o processo de envio das chaves para o calculo da chave secreta compartilhada;
	 *
	 * 1) Cliente 1 --> Calcula valor publico e envia para o Cliente 2;
	 * 2) Cliente 2 --> Recebe valor publico do Cliente 1, calcula sua chave secreta compartilhada, calcula seu valor publico e envia para Cliente 1;
	 * 3) Cliente 1 --> Recebe valor publico do Cliente 2 e calcula sua chave secreta compartilhada;
	 */
	private void enviaChaveSecretaCompartilhada() {
		System.out.println("Iniciando calculo de chave secreta compartilhada.\n");
		//Calcula valor publico
		Long valorPublico = Encrypt.calculatePower(ServidorController.chavePublica2, cliente.getChavePrivada(), ServidorController.chavePublica1);
		System.out.println("Chave privada de "+ cliente.getNmCliente() + ": " + cliente.getChavePrivada());
		System.out.println("Chave publica de "+ cliente.getNmCliente() + ": " + ServidorController.chavePublica1);
		System.out.println("Valor publico de " + cliente.getNmCliente() + ": " + valorPublico + "\n");
		//Monta a mensagem
		String mensagem = cliente.getSocket().getLocalPort() + "|" + cliente.getNmCliente() + "|" + "CRYPTO" + String.valueOf(valorPublico);
		//Envia a mensagem
		enviar(String.valueOf(mensagem));
	
	}
	
	/**
	 *M�todo que envia a mensagem;
	 */
	private void enviar(String msg) {
		try {
			PrintWriter pr = new PrintWriter(cliente.getSocket().getOutputStream());
			pr.print(msg);
			pr.flush();
			System.out.println("[Cliente] Usuario " + cliente.getNmCliente() + ", enviando mensagem:  " + msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void startThreadEscuta() {
		new Thread(escuta).start();
	}
	
	public void exibirPainel() {
		painel.setVisible(true);
	}

}
