package chat.cliente;
import java.net.Socket;

/**
 *Classe Cliente.
 */
public class Cliente {
	
	private String nmCliente;
	private Socket socket;
	private EscutaCliente escutaCliente;
	private Long chavePrivada;
	private Long chaveSecretaCompartilhada;
	
	public String getNmCliente() {
		return nmCliente;
	}
	public void setNmCliente(String nmCliente) {
		this.nmCliente = nmCliente;
	}
	public Socket getSocket() {
		return socket;
	}
	public void setSocket(Socket socket) {
		this.socket = socket;
	}
	public EscutaCliente getEscutaCliente() {
		return escutaCliente;
	}
	public void setEscutaCliente(EscutaCliente escutaCliente) {
		this.escutaCliente = escutaCliente;
		escutaCliente.startThreadEscuta();
	}
	public Long getChavePrivada() {
		return chavePrivada;
	}
	public void setChavePrivada(Long chavePrivada) {
		this.chavePrivada = chavePrivada;
	}
	public Long getChaveSecretaCompartilhada() {
		return chaveSecretaCompartilhada;
	}
	public void setChaveSecretaCompartilhada(Long chaveSecretaCompartilhada) {
		this.chaveSecretaCompartilhada = chaveSecretaCompartilhada;
	}
}
