package chat.cliente;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.jgoodies.common.base.Strings;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;

import chat.servidor.ServidorController;


/**
 *Painel que possibilita conectar um usu�rio ao servidor.
 */
@SuppressWarnings("serial")
public class ConexaoClienteFrm extends JFrame{
	
	private JTextField tfNomeUsuarioA;
	private JTextField tfNomeUsuarioB;
	private JButton btnConectar;
	
	public ConexaoClienteFrm() {
		initComponents();
		initListeners();
		initLayout();
		
		pack();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
	}
	
	private void initLayout() {	
		DefaultFormBuilder builder = new DefaultFormBuilder(new FormLayout("pref, 2dlu, 60dlu, 2dlu, pref, 2dlu, 20dlu", "18dlu, 18dlu, 25dlu"));
		builder.border(new EmptyBorder(5, 5, 5, 5));
		builder.append("Usuario A: ", tfNomeUsuarioA, 5);
		builder.nextLine();
		builder.append("Usuario B: ", tfNomeUsuarioB, 5);
		builder.nextLine();
		builder.append(btnConectar, 7);
		builder.nextLine();

		add(builder.getPanel(), BorderLayout.CENTER);
	}
	
	private void initComponents() {
		tfNomeUsuarioA = new JTextField();
		tfNomeUsuarioB = new JTextField();
		btnConectar = new JButton("Iniciar Chat");
	}

	private void initListeners() {
		btnConectar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(validarClientes()) {
					adicionarClientesAoServidor();
					dispose();
				}else {
					System.out.println("Erro: Entradas inv�lidas, usuarios n�o podem ser nulos!\n");
				}
			}
		});
	}
	
	private void adicionarClientesAoServidor() {
		adicionarClienteAoServidor(tfNomeUsuarioA.getText(), ServidorController.chavePrivada1);
		adicionarClienteAoServidor(tfNomeUsuarioB.getText(), ServidorController.chavePrivada2);
	}
	
	
  
	private void adicionarClienteAoServidor(String userName, Long v) {
		Cliente c = new Cliente();
		c.setNmCliente(userName);
		c.setChavePrivada(v);
		ServidorController.adicionarCliente(c);
	}

	private boolean validarClientes() {
		return Strings.isNotBlank(tfNomeUsuarioA.getText())
			&& Strings.isNotBlank(tfNomeUsuarioB.getText())
			&& ServidorController.isServidorAtivo() ? true : false;
	}
}
