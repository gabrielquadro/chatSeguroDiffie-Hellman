package chat;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;

import chat.cliente.Cliente;


/**
 *Painel que possibilita visualizar o envio e recebimento de mensagens entre os usu�rios.
 */
@SuppressWarnings("serial")
public class PainelChatFrm extends JFrame{

	private JTextArea taChat;
	private JTextField ftEntrada;
	private JButton btnEnviar;
	private Cliente cliente;
	
	/**
	 *Construtor responsavel por inicializar o painel.
	 */
	public PainelChatFrm(Cliente cliente) {
		this.cliente = cliente;
		setLayout(new BorderLayout());
		initComponents();
		initListeners();
		initLayout();
		setTitle(cliente.getNmCliente() + " | " +  cliente.getSocket().getLocalPort());
		pack();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	/**
	 *M�todo responsavel por inicializar os componentes da tela.
	 */
	private void initComponents() {
		taChat = new JTextArea();
		ftEntrada = new JTextField();
		btnEnviar = new JButton("Enviar");
	}

	
	/**
	 *M�todo responsavel por inicializar os listeners da tela.
	 */
	private void initListeners() {
		btnEnviar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				cliente.getEscutaCliente().enviarMensagem(ftEntrada.getText());
			}
		});
	
	}

	/**
	 *M�todo responsavel por inicializar o layout da tela.
	 */
	private void initLayout() {
		DefaultFormBuilder builder = new DefaultFormBuilder(new FormLayout("130dlu, 2dlu, 40dlu", "fill:80dlu, 18dlu"));
		builder.border(new EmptyBorder(5, 5, 5, 5));
		builder.append(new JScrollPane(taChat), 3);
		taChat.setEnabled(false);
		builder.nextLine();
		builder.append(ftEntrada);
		builder.append(btnEnviar);
		add(builder.getPanel(), BorderLayout.CENTER);
	}
	
	public JTextField getFtEntrada() {
		return ftEntrada;
	}
	
	public JTextArea getTaChat() {
		return taChat;
	}
}
