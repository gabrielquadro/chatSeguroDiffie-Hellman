package chat.main;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;

import chat.cliente.ConexaoClienteFrm;
import chat.enums.StatusServidor;
import chat.enums.TipoCryptoEnum;
import chat.servidor.ServidorController;


/**
 *Painel que possibilita inicializar o servidor e adicionar clientes;
 */
@SuppressWarnings("serial")
public class MenuPrincipalFrm extends JFrame{
	
	private JLabel lblstatusServidor;
	private JButton btnCriarCliente;
	private JButton btnCriarServidor;
	private JComboBox<TipoCryptoEnum> cmbTipoCrypto;
	
	public MenuPrincipalFrm() {
		initComponents();
		initListeners();
		initLayout();
		pack();
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
	}
	
	private void initLayout() {	
		DefaultFormBuilder builder = new DefaultFormBuilder(new FormLayout("60dlu, 6dlu, 40dlu", "18dlu, 18dlu, 18dlu, 18dlu"));
		builder.border(new EmptyBorder(5, 5, 5, 5));
		builder.append("Server Status: ",lblstatusServidor);
		builder.nextLine();
		builder.append("Criptografia: ", cmbTipoCrypto);
		builder.nextLine();
		builder.append(btnCriarServidor,3);
		builder.nextLine();
		builder.append(btnCriarCliente,3);
		builder.nextLine();

		add(builder.getPanel(), BorderLayout.CENTER);
	}
	
	private void initComponents() {
		btnCriarCliente = new JButton("Criar Clientes");
		btnCriarServidor = new JButton("Start Server");
		cmbTipoCrypto = new JComboBox<TipoCryptoEnum>(TipoCryptoEnum.values());
		updateStatusServidor(StatusServidor.INATIVO);
	}

	private void initListeners() {
		btnCriarCliente.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(ServidorController.isServidorAtivo()) {
					new ConexaoClienteFrm();
				}else {
					System.out.println("Server Offline!");
				}
			}
		});
		
		btnCriarServidor.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!ServidorController.isServidorAtivo()) {
					ServidorController.startServer((TipoCryptoEnum) cmbTipoCrypto.getSelectedItem());
					updateStatusServidor(StatusServidor.ATIVO);
					habilitarComboCrypto(false);
				}
			}
		});
	}
	
	private void updateStatusServidor(StatusServidor status) {
		if(null == lblstatusServidor) {
			lblstatusServidor = new JLabel();
		}
		lblstatusServidor.setText(status.getMeaning());
	}
	
	private void habilitarComboCrypto(Boolean b) {
		cmbTipoCrypto.setEnabled(b);
	}
}
