package chat.enums;

public enum TipoCryptoEnum {
	 C128(16), C192(24), C256(32);
	
	private final Integer size;
	
	private TipoCryptoEnum(Integer size) {
        this.size = size;
    }

	public Integer getSize() {
		return size;
	}
	
}
