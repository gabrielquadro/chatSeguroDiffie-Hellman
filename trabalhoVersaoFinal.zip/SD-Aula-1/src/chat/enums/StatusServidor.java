package chat.enums;

public enum StatusServidor {
    ATIVO("Ativo"),
    INATIVO("Inativo");

    private final String meaning;

    private StatusServidor(String meaning) {
        this.meaning = meaning;
    }
    
	public String getMeaning() {
		return meaning;
	}
    
}
